(* ::Package:: *)

Paclet[
Name -> "ESML",
Version -> "0.1.0",
MathematicaVersion -> "8+",
Extensions -> {{
    "Documentation", 
    Resources -> {
        "ReferencePages/ESML"
    }, 
    Language -> "English"
}}
]
